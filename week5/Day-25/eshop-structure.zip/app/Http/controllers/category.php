<?php 

    // setup everything we need for the project
    $site_url = 'http://www.cbp-exercises.test/eshop';

    // set the content
    $content = 'category/layout.php';

    // when we are ready with setup, include the wrapper
    include 'views/html-wrapper.php'; 
    
?>