<div class="cart_bar">
    <a href="<?= $site_url ?>/cart.php">
        Cart: 0 items, 0 Kč
    </a>
</div>