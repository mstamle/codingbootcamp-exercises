<div id="homepage">

    <?php include 'top-products.php'; ?>

    <?php include 'categories.php'; ?>

    <?php include 'shop-info.php'; ?>

</div>