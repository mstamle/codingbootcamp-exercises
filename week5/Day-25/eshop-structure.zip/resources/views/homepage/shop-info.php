<div class="shop_info">
    <h2>About our eshop</h2>
    <p>Shop with us! Don't try the competition! We are the best! <strong>Pleeeaaasee!</strong></p>  
</div>