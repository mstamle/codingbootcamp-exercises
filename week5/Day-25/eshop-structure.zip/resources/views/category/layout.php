<div id="category">
  
    <?php include 'products.php'; ?>

    <?php include 'subcategories.php'; ?>

</div>