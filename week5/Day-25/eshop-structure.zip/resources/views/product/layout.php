<div id="product">
    
    <h1>Lenovo IdeaCentre 300-22ISU Black</h1>

    <div class="product_info">

        <?php include 'main-image.php'; ?>

        <?php include 'description.php'; ?>

        <?php include 'order-form.php'; ?>

    </div>

    <?php include 'gallery.php'; ?>

</div>  