<div class="order">
    <form action="" method="POST">
        <input type="submit" value="Order" name="order" />
        <input type="text" value="1" name="amount" />
        * 10999 &euro;
    </form>
</div>