<div class="gallery">

    <h2>Gallery</h2>
    <div class="images">

        <a class="image" href="media/product/5/5-1.jpg">
        <img src="media/product/5/5-1.jpg" /></a>
    
        <a class="image" href="media/product/5/5-2.jpg">
        <img src="media/product/5/5-2.jpg" /></a>
    
        <a class="image" href="media/product/5/5-3.jpg">
        <img src="media/product/5/5-3.jpg" /></a>
    
        <a class="image" href="media/product/5/5-4.jpg">
        <img src="media/product/5/5-4.jpg" /></a>
    
        <a class="image" href="media/product/5/5-5.jpg">
        <img src="media/product/5/5-5.jpg" /></a>
    
        <a class="image" href="media/product/5/5-6.jpg">
        <img src="media/product/5/5-6.jpg" /></a>
    
        <a class="image" href="media/product/5/5-7.jpg">
        <img src="media/product/5/5-7.jpg" /></a>
    
        <a class="image" href="media/product/5/5-8.jpg">
        <img src="media/product/5/5-8.jpg" /></a>
        
    </div>    

</div>