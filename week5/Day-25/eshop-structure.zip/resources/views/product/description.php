<div class="description">
    All In One PC - 21.5 "LED 1920x1080 IPS, Intel Celeron Dual Core 3855 Skylake, RAM 4 gigabytes DDR4, Intel HD Graphics 510, HDD 500 gigabytes 7200 RPM, DVD burner, WiFi, Bluetooth 4.0, HD webcam, HDMI, USB 3.0, card reader, speakers, USB keyboard and mouse, Windows 10 Home 64bit    
</div>