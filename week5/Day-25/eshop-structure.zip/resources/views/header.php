<div id="header">
    <h1>
        <a href="<?= $site_url ?>">
            <img src="img/my-shop.png" alt="MY SHOP" /></a>
    </h1>

    <?php include 'language-select.php'; ?>

</div>