<nav id="lang">
  <form action="" method="post">
    <select name="change_language" onchange="this.form.submit()">
        <option value="en"  selected>English</option>
        <option value="cs" >Czech</option>
        <option value="sp" >Spanish</option>
    </select>
  </form>
</nav>