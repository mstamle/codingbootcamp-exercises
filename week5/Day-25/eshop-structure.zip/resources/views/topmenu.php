<div id="topmenu">
    <nav>
        <a href="<?= $site_url ?>">My HOME</a>
        <a href="<?= $site_url ?>/category.php">products</a>
        <a href="<?= $site_url ?>/contact.php">contact form</a>
    </nav>

    <?php include 'cart-bar.php'; ?>
</div>