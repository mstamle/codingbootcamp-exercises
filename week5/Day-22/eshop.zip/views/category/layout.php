<div id="category">
  
    <!-- products -->

    <!-- subcategories -->

</div>