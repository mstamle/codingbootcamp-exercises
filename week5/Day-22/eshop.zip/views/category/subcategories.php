<div class="subcategories">
    <h2>Subcategories</h2>
    <ul>

        <li>
            <a href="<?= $site_url ?>/category.php?category_id=4">Appliances</a>
        </li>


        <li>
            <a href="<?= $site_url ?>/category.php?category_id=2">Mobile phones</a>
        </li>


        <li>
            <a href="<?= $site_url ?>/category.php?category_id=1">PCs & Laptops</a>
        </li>


        <li>
            <a href="<?= $site_url ?>/category.php?category_id=3">Televisions</a>
        </li>

    </ul>  
</div>