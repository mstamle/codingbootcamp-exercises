<div id="header">
    <h1>
        <a href="<?= $site_url ?>">
            <img src="img/my-shop.png" alt="MY SHOP" /></a>
    </h1>

    <!-- language-select -->

</div>