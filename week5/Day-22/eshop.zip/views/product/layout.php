<div id="product">
    
    <h1>Lenovo IdeaCentre 300-22ISU Black</h1>

    <div class="product_info">

        <!-- main-image -->

        <!-- description -->

        <!-- order-form -->

    </div>

    <!-- gallery -->

</div>  