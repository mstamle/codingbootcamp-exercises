<div class="main_image">
    <img src="media/product/5/5-1.jpg" />
</div>