<div id="topmenu">
    <nav>
        <a href="<?= $site_url ?>">My HOME</a>
        <a href="<?= $site_url ?>/products.php">products</a>
        <a href="<?= $site_url ?>/contact.php">contact form</a>
    </nav>

    <!-- cart-bar -->
</div>