<div id="homepage">

    <!-- top-products -->

    <!-- categories -->

    <!-- shop-info -->

</div>