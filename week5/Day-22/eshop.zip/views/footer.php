<div id="footer">
    &copy; 2018 Dr. Evil  
</div>